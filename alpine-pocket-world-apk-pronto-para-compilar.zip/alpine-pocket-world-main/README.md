# Alpine Pocket World

PROJETO: OS LAB ANDROID — EMULADOR E LABORATÓRIO LINUX



Desenvolva um aplicativo Android chamado OS LAB ANDROID.



O aplicativo deverá ser instalado diretamente em celulares Android por meio de um arquivo APK.



ATENÇÃO: NÃO QUERO APENAS UM SITE RESPONSIVO OU UMA PÁGINA WEB. QUERO UM APLICATIVO ANDROID REAL, COM ESTRUTURA NATIVA E PREPARADO PARA INSTALAÇÃO.



1. FORMATO DO APLICATIVO



O resultado final deverá permitir gerar:



- APK para instalação direta no Android.

- APK de versão de testes (debug).

- APK de versão final (release).

- Projeto-fonte Android para futuras atualizações.



Utilizar Android Studio, Kotlin e Android SDK para a parte nativa.



Caso utilize React para a interface, integrar com Android através de Capacitor, mantendo os recursos nativos necessários.



Não entregar somente um endereço de site.



2. OBJETIVO



Criar um laboratório de virtualização e emulação de sistemas operacionais Linux que funcione diretamente no celular Android.



O aplicativo deverá permitir:



- Criar máquinas virtuais.

- Instalar sistemas Linux.

- Executar distribuições Linux.

- Inicializar sistemas através de imagens ISO.

- Acessar terminais.

- Visualizar interfaces gráficas.

- Testar comandos.

- Salvar máquinas virtuais.

- Reiniciar e desligar sistemas.



3. DISTRIBUIÇÃO PRINCIPAL



Utilizar como primeira distribuição o Alpine Linux, a mesma distribuição utilizada no meu projeto OS Paranormal 0.0.6.



Analisar os arquivos do ZIP original, especialmente a pasta OS e seus scripts.



Priorizar suporte ARM64 (AArch64), por ser uma arquitetura comum nos celulares Android atuais.



Preparar também suporte a x86_64 através de emulação, quando tecnicamente possível.



4. MOTOR DE VIRTUALIZAÇÃO ANDROID



O aplicativo deverá utilizar um mecanismo de emulação compatível com Android.



Avaliar a utilização de:



- QEMU para Android.

- QEMU System ARM64.

- QEMU TCG para emulação de processador.

- Android NDK para integração nativa.

- Armazenamento privado do aplicativo para discos virtuais.



Não depender de KVM, pois muitos aparelhos Android não disponibilizam acesso a esse recurso.



O objetivo é executar uma máquina Linux dentro do próprio celular.



Não utilizar apenas uma simulação de terminal.



Não apresentar comandos fictícios como se fossem comandos executados em Linux real.



5. INTERFACE DO APLICATIVO



Criar uma interface moderna, com:



- Fundo preto.

- Detalhes vermelhos.

- Visual tecnológico.

- Menus intuitivos.

- Compatibilidade com telas pequenas.

- Navegação por toque.



Criar as seguintes áreas:



1. Dashboard.

2. Máquinas virtuais.

3. Sistemas Linux.

4. Terminal.

5. Arquivos ISO.

6. Armazenamento.

7. Monitor do sistema.

8. Configurações.



6. GERENCIADOR DE MÁQUINAS



Permitir criar máquinas virtuais com:



- Nome.

- Distribuição.

- Arquitetura.

- Memória RAM.

- Processadores virtuais.

- Armazenamento.

- Imagem ISO.



Permitir iniciar, pausar, reiniciar, desligar e excluir máquinas.



Os limites deverão respeitar os recursos disponíveis no celular.



7. GERENCIADOR DE IMAGENS ISO



Permitir selecionar imagens ISO através do seletor de arquivos do Android.



Permitir:



- Importar ISO.

- Visualizar tamanho.

- Identificar arquitetura.

- Selecionar ISO para inicialização.

- Excluir imagens.

- Manter imagens salvas.



Não presumir que toda ISO de computador funcionará em Android.



8. TERMINAL REAL



Criar um terminal conectado à máquina Linux em execução.



Permitir executar comandos reais, como:



uname -a

ls

pwd

apk update

apk add nano

free -h

df -h

ip addr



Mostrar resultados reais, erros e histórico de comandos.



9. TELA DA MÁQUINA VIRTUAL



Criar uma tela que mostre a execução do Linux.



Permitir:



- Visualizar o boot.

- Interagir com o sistema.

- Utilizar teclado virtual.

- Utilizar mouse virtual.

- Ajustar resolução.

- Alternar entre tela cheia e janela.



10. ARMAZENAMENTO E DESEMPENHO



Criar gerenciamento de recursos.



Mostrar:



- RAM utilizada.

- CPU utilizada.

- Armazenamento utilizado.

- Espaço disponível.

- Temperatura do aparelho, quando disponível.



Permitir configurar limites de utilização para evitar travamentos e superaquecimento.



Salvar os discos virtuais no armazenamento privado do aplicativo.



11. FUNCIONAMENTO OFFLINE



A prioridade é que o aplicativo consiga executar as máquinas virtuais localmente, sem internet.



A internet será necessária apenas para baixar imagens Linux, atualizações e outros arquivos quando solicitado.



Não depender de um servidor externo para a execução básica das máquinas.



12. COMPATIBILIDADE ANDROID



Preparar o aplicativo para Android 10 ou superior, respeitando as limitações de cada aparelho.



Implementar:



- Permissões de armazenamento apropriadas.

- Seletor de arquivos Android.

- Gerenciamento de memória.

- Controle de processos.

- Tratamento de erros.

- Salvamento de estado.

- Compatibilidade com diferentes resoluções.



13. RESULTADO FINAL



Quero receber um projeto Android que possa ser compilado e transformado em APK.



Quero instalar o OS LAB ANDROID no meu celular e conseguir executar o Alpine Linux de verdade, visualizar sua inicialização, abrir seu terminal e testar o sistema.



Prioridade máxima: execução local no Android, sem necessidade de computador ou servidor externo.



Se alguma funcionalidade não puder ser implementada diretamente pelo Lovable, apresentar o código-fonte necessário e as instruções de compilação no Android Studio.



Não substituir a virtualização real por uma interface demonstrativa.



Entregar uma versão funcional, documentada e preparada para testes.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/3bae13a0-f8ba-4310-b8ff-90e288af1c52).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
