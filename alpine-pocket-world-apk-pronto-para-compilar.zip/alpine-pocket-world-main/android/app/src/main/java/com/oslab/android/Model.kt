package com.oslab.android

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class VmStatus { PARADA, EXECUTANDO, PAUSADA }

data class Vm(
    val id: String, val name: String, val distro: String, val arch: String,
    val ramMB: Int, val cpus: Int, val diskGB: Int, val isoPath: String?,
)

data class Iso(val path: String, val name: String, val sizeBytes: Long, val arch: String)

data class Settings(val maxCpuPercent: Int = 75, val maxTempC: Int = 42, val keepScreenOn: Boolean = true)

/** Persistência simples em JSON no armazenamento privado do app (filesDir). */
class Repo(private val ctx: Context) {
    val vmDir = File(ctx.filesDir, "vms").apply { mkdirs() }
    val isoDir = File(ctx.filesDir, "isos").apply { mkdirs() }
    private val vmsFile = File(ctx.filesDir, "vms.json")
    private val prefs = ctx.getSharedPreferences("oslab", Context.MODE_PRIVATE)

    fun diskOf(vm: Vm) = File(vmDir, "${vm.id}.qcow2")

    fun loadVms(): List<Vm> = runCatching {
        val arr = JSONArray(vmsFile.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Vm(o.getString("id"), o.getString("name"), o.getString("distro"), o.getString("arch"),
                o.getInt("ramMB"), o.getInt("cpus"), o.getInt("diskGB"), o.optString("isoPath").ifEmpty { null })
        }
    }.getOrDefault(emptyList())

    fun saveVms(vms: List<Vm>) {
        val arr = JSONArray()
        vms.forEach { v ->
            arr.put(JSONObject().put("id", v.id).put("name", v.name).put("distro", v.distro).put("arch", v.arch)
                .put("ramMB", v.ramMB).put("cpus", v.cpus).put("diskGB", v.diskGB).put("isoPath", v.isoPath ?: ""))
        }
        File(vmsFile.path + ".tmp").apply { writeText(arr.toString()); renameTo(vmsFile) }
    }

    fun listIsos(): List<Iso> = isoDir.listFiles()?.filter { it.isFile }?.map {
        Iso(it.absolutePath, it.name, it.length(), detectArch(it))
    }?.sortedBy { it.name } ?: emptyList()

    fun loadSettings() = Settings(prefs.getInt("cpu", 75), prefs.getInt("temp", 42), prefs.getBoolean("screen", true))
    fun saveSettings(s: Settings) = prefs.edit().putInt("cpu", s.maxCpuPercent).putInt("temp", s.maxTempC).putBoolean("screen", s.keepScreenOn).apply()

    companion object {
        /** Procura o carregador EFI dentro da ISO; cai para o nome do arquivo se não achar. */
        fun detectArch(f: File): String {
            val n = f.name.lowercase()
            runCatching {
                f.inputStream().buffered().use { input ->
                    val buf = ByteArray(1 shl 20); var total = 0L
                    while (total < 64L * 1024 * 1024) {
                        val r = input.read(buf); if (r <= 0) break; total += r
                        val s = String(buf, 0, r, Charsets.ISO_8859_1).uppercase()
                        if (s.contains("BOOTAA64")) return "aarch64"
                        if (s.contains("BOOTX64")) return "x86_64"
                    }
                }
            }
            return when {
                n.contains("aarch64") || n.contains("arm64") -> "aarch64"
                n.contains("x86_64") || n.contains("amd64") -> "x86_64"
                else -> "desconhecida"
            }
        }
    }
}

/** Limites: metade da RAM, um núcleo livre e 80% do espaço livre. Mesma regra da interface web. */
data class Limits(val maxRamMB: Int, val maxCpus: Int, val maxDiskGB: Int)
fun limitsFor(totalRamMB: Long, cores: Int, freeGB: Long, cpuPercent: Int): Limits {
    val ram = maxOf(256, (totalRamMB / 2 / 64 * 64).toInt())
    val cpus = maxOf(1, minOf(cores - 1, (cores * cpuPercent / 100.0).toInt()))
    return Limits(ram, cpus, maxOf(1, (freeGB * 0.8).toInt()))
}
