package com.oslab.android

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.*

/** Mantém as VMs vivas em segundo plano e pausa tudo se o aparelho esquentar demais. */
class VmService : Service() {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vm", "Máquinas virtuais", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "vm").setContentTitle("OS LAB ANDROID")
            .setContentText("Máquina virtual em execução").setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(1, n)
        wake = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "oslab:vm").apply { acquire(6 * 60 * 60 * 1000L) }
        scope.launch {
            val repo = Repo(this@VmService)
            while (isActive) {
                delay(5000)
                if (QemuEngine.running.value.isEmpty()) { stopSelf(); break }
                val t = batteryTempC(this@VmService)
                if (t != null && t >= repo.loadSettings().maxTempC) QemuEngine.pauseAll()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() { scope.cancel(); wake?.takeIf { it.isHeld }?.release(); super.onDestroy() }

    companion object {
        fun ensure(ctx: Context) = ctx.startForegroundService(Intent(ctx, VmService::class.java))
        fun batteryTempC(ctx: Context): Float? {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
            val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            return if (t == Int.MIN_VALUE) null else t / 10f
        }
    }
}
