package com.oslab.android

import android.content.Context
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.io.OutputStream
import java.net.Socket

/**
 * Executa o QEMU real (binários em jniLibs, ver scripts/fetch-qemu.py).
 * - Console serial ligado ao stdin/stdout do processo -> Terminal.
 * - Tela via VNC em 127.0.0.1 -> VncView.
 * - Controle (pausar/reiniciar/desligar) via QMP em 127.0.0.1.
 */
object QemuEngine {
    class Running(val vm: Vm, val process: Process, val stdin: OutputStream, val vncPort: Int, val qmpPort: Int)

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val _running = MutableStateFlow<Map<String, Running>>(emptyMap())
    val running: StateFlow<Map<String, Running>> = _running
    private val _status = MutableStateFlow<Map<String, VmStatus>>(emptyMap())
    val status: StateFlow<Map<String, VmStatus>> = _status
    private val _console = MutableStateFlow<Map<String, String>>(emptyMap())
    val console: StateFlow<Map<String, String>> = _console

    private fun libDir(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir)
    private fun bin(ctx: Context, name: String) = File(libDir(ctx), name)

    fun available(ctx: Context, arch: String) = bin(ctx, if (arch == "x86_64") "libqemu-system-x86_64.so" else "libqemu-system-aarch64.so").exists()

    /** Copia firmware/keymaps de assets/qemu-share para filesDir (uma vez por versão). */
    private fun shareDir(ctx: Context): File {
        val dst = File(ctx.filesDir, "qemu-share")
        val stamp = File(dst, ".v${BuildConfigCompat.versionCode(ctx)}")
        if (!stamp.exists()) {
            dst.deleteRecursively(); dst.mkdirs()
            fun copy(path: String, out: File) {
                val kids = ctx.assets.list(path) ?: emptyArray()
                if (kids.isEmpty()) ctx.assets.open(path).use { i -> out.outputStream().use { i.copyTo(it) } }
                else { out.mkdirs(); kids.forEach { copy("$path/$it", File(out, it)) } }
            }
            runCatching { copy("qemu-share", dst) }
            stamp.createNewFile()
        }
        return dst
    }

    private fun env(ctx: Context, pb: ProcessBuilder) {
        pb.environment()["LD_LIBRARY_PATH"] = libDir(ctx).absolutePath
        pb.environment()["TMPDIR"] = ctx.cacheDir.absolutePath
        pb.environment()["HOME"] = ctx.filesDir.absolutePath
    }

    fun ensureDisk(ctx: Context, repo: Repo, vm: Vm): Result<Unit> = runCatching {
        val disk = repo.diskOf(vm)
        if (disk.exists()) return@runCatching
        val pb = ProcessBuilder(bin(ctx, "libqemu-img.so").absolutePath, "create", "-f", "qcow2", disk.absolutePath, "${vm.diskGB}G")
        env(ctx, pb); pb.redirectErrorStream(true)
        val p = pb.start(); val out = p.inputStream.bufferedReader().readText()
        if (p.waitFor() != 0) error("qemu-img falhou: $out")
    }

    fun start(ctx: Context, repo: Repo, vm: Vm): Result<Unit> = runCatching {
        if (_running.value.containsKey(vm.id)) return@runCatching
        check(available(ctx, vm.arch)) { "Motor QEMU para ${vm.arch} não está incluído neste APK. Rode scripts/fetch-qemu.py antes de compilar." }
        ensureDisk(ctx, repo, vm).getOrThrow()
        val idx = _running.value.size
        val vncDisplay = 1 + idx; val qmpPort = 4440 + idx
        val share = shareDir(ctx)
        val disk = repo.diskOf(vm).absolutePath
        val args = mutableListOf<String>()
        if (vm.arch == "x86_64") {
            args += listOf(bin(ctx, "libqemu-system-x86_64.so").absolutePath, "-L", share.absolutePath,
                "-M", "q35", "-cpu", "max", "-vga", "std",
                "-drive", "file=$disk,if=virtio,format=qcow2")
            vm.isoPath?.let { args += listOf("-cdrom", it, "-boot", "order=dc") }
        } else {
            args += listOf(bin(ctx, "libqemu-system-aarch64.so").absolutePath, "-L", share.absolutePath,
                "-M", "virt", "-cpu", "cortex-a57",
                "-bios", File(share, "edk2-aarch64-code.fd").absolutePath,
                "-device", "virtio-gpu-pci", "-device", "qemu-xhci", "-device", "usb-kbd", "-device", "usb-tablet",
                "-drive", "file=$disk,if=none,id=hd0,format=qcow2", "-device", "virtio-blk-pci,drive=hd0")
            vm.isoPath?.let {
                args += listOf("-device", "virtio-scsi-pci", "-drive", "file=$it,if=none,id=cd0,media=cdrom,readonly=on", "-device", "scsi-cd,drive=cd0,bootindex=0")
            }
        }
        // TCG: emulação por software, não depende de KVM.
        args += listOf("-accel", "tcg,thread=multi", "-smp", "${vm.cpus}", "-m", "${vm.ramMB}",
            "-netdev", "user,id=n0", "-device", "virtio-net-pci,netdev=n0",
            "-display", "vnc=127.0.0.1:$vncDisplay", "-serial", "stdio", "-monitor", "none",
            "-qmp", "tcp:127.0.0.1:$qmpPort,server=on,wait=off")
        val pb = ProcessBuilder(args); env(ctx, pb); pb.redirectErrorStream(true)
        val p = pb.start()
        val r = Running(vm, p, p.outputStream, 5900 + vncDisplay, qmpPort)
        _running.value = _running.value + (vm.id to r)
        setStatus(vm.id, VmStatus.EXECUTANDO)
        appendConsole(vm.id, "[OS LAB] ${args.joinToString(" ")}\n")
        scope.launch {
            val buf = ByteArray(4096)
            val ins = p.inputStream
            while (true) { val n = ins.read(buf); if (n < 0) break; appendConsole(vm.id, String(buf, 0, n)) }
            val code = p.waitFor()
            appendConsole(vm.id, "\n[OS LAB] QEMU encerrou (código $code)\n")
            _running.value = _running.value - vm.id
            setStatus(vm.id, VmStatus.PARADA)
        }
        VmService.ensure(ctx)
    }

    private fun setStatus(id: String, s: VmStatus) { _status.value = _status.value + (id to s) }
    private fun appendConsole(id: String, s: String) {
        val clean = s.replace(Regex("\u001B\\[[0-9;?]*[A-Za-z]"), "").replace("\r", "")
        val cur = (_console.value[id] ?: "") + clean
        _console.value = _console.value + (id to cur.takeLast(200_000))
    }

    fun send(id: String, line: String) = scope.launch {
        _running.value[id]?.let { runCatching { it.stdin.write(line.toByteArray()); it.stdin.flush() } }
    }

    /** Envia um comando QMP real (stop, cont, system_reset, system_powerdown, quit). */
    fun qmp(id: String, cmd: String) = scope.launch {
        val r = _running.value[id] ?: return@launch
        runCatching {
            Socket("127.0.0.1", r.qmpPort).use { s ->
                val w = s.getOutputStream().bufferedWriter(); val rd = s.getInputStream().bufferedReader()
                rd.readLine()
                w.write("{\"execute\":\"qmp_capabilities\"}\n"); w.flush(); rd.readLine()
                w.write("{\"execute\":\"$cmd\"}\n"); w.flush(); rd.readLine()
            }
            when (cmd) { "stop" -> setStatus(id, VmStatus.PAUSADA); "cont", "system_reset" -> setStatus(id, VmStatus.EXECUTANDO) }
        }.onFailure { appendConsole(id, "\n[OS LAB] QMP falhou: ${it.message}\n") }
    }

    fun kill(id: String) { _running.value[id]?.process?.destroy() }

    fun pauseAll() = _running.value.keys.forEach { qmp(it, "stop") }

    /** Tempo de CPU (jiffies) do processo QEMU; usado pelo monitor. */
    fun cpuTicks(id: String): Long? = runCatching {
        val pid = _running.value[id]!!.process.toString().substringAfter("pid=").takeWhile { it.isDigit() }
        val f = File("/proc/$pid/stat").readText().substringAfterLast(")").trim().split(" ")
        f[11].toLong() + f[12].toLong()
    }.getOrNull()
}

object BuildConfigCompat {
    @Suppress("DEPRECATION")
    fun versionCode(ctx: Context) = ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionCode
}
