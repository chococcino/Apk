package com.oslab.android

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFD84A43), background = Color(0xFF0A0A0A),
                    surface = Color(0xFF14141A), onBackground = Color(0xFFEEEEEE), onSurface = Color(0xFFEEEEEE),
                ),
            ) { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() } }
        }
    }
}

private fun deviceLimits(ctx: Context, settings: Settings): Limits {
    val info = ActivityManager.MemoryInfo()
    ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(info)
    val freeGB = ctx.filesDir.usableSpace / (1024L * 1024 * 1024)
    return limitsFor(info.totalMem / (1024 * 1024), Runtime.getRuntime().availableProcessors(), freeGB, settings.maxCpuPercent)
}

private fun fmtBytes(b: Long): String {
    val u = listOf("B", "KB", "MB", "GB"); var v = b.toDouble(); var i = 0
    while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
    return String.format("%.1f %s", v, u[i])
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val repo = remember { Repo(ctx) }
    var vms by remember { mutableStateOf(repo.loadVms()) }
    var isos by remember { mutableStateOf(repo.listIsos()) }
    var settings by remember { mutableStateOf(repo.loadSettings()) }
    var tab by remember { mutableStateOf(0) }
    var terminalVm by remember { mutableStateOf<String?>(null) }

    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val activity = ctx as? ComponentActivity
    LaunchedEffect(settings.keepScreenOn) {
        if (settings.keepScreenOn) activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                listOf("Máquinas" to Icons.Filled.Computer, "ISOs" to Icons.Filled.Storage,
                    "Terminal" to Icons.Filled.Terminal, "Config." to Icons.Filled.Settings)
                    .forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, contentDescription = label) }, label = { Text(label) })
                    }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> MachinesScreen(repo, vms, isos, settings,
                    onVms = { vms = it; repo.saveVms(it) },
                    onOpenTerminal = { terminalVm = it; tab = 2 })
                1 -> IsosScreen(repo, isos) { isos = repo.listIsos() }
                2 -> TerminalScreen(vms, terminalVm) { terminalVm = it }
                else -> SettingsScreen(settings) { settings = it; repo.saveSettings(it) }
            }
        }
    }
}

@Composable
fun Title(text: String) = Text(text, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)

@Composable
fun MachinesScreen(repo: Repo, vms: List<Vm>, isos: List<Iso>, settings: Settings,
                   onVms: (List<Vm>) -> Unit, onOpenTerminal: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val status by QemuEngine.status.collectAsState()
    var creating by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Title("Máquinas virtuais")
            Spacer(Modifier.height(8.dp))
            Button(onClick = { creating = true }) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(8.dp)); Text("Nova máquina") }
            message?.let { Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp)) }
        }
        if (vms.isEmpty()) item { Text("Nenhuma máquina ainda.", color = Color.Gray) }
        items(vms, key = { it.id }) { vm ->
            val st = status[vm.id] ?: VmStatus.PARADA
            val engine = QemuEngine.available(ctx, vm.arch)
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(vm.name, style = MaterialTheme.typography.titleMedium)
                    Text("${vm.distro} · ${vm.arch} · ${vm.ramMB} MB · ${vm.cpus} CPU · ${vm.diskGB} GB", color = Color.Gray, fontSize = 13.sp)
                    Text("Estado: ${st.name.lowercase()}", fontSize = 13.sp)
                    if (!engine) Text("Motor QEMU para ${vm.arch} não está incluído neste APK.", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        when (st) {
                            VmStatus.PARADA -> {
                                Button(enabled = engine, onClick = {
                                    scope.launch {
                                        val r = withContext(Dispatchers.IO) { QemuEngine.start(ctx, repo, vm) }
                                        message = r.exceptionOrNull()?.message
                                        if (r.isSuccess) onOpenTerminal(vm.id)
                                    }
                                }) { Icon(Icons.Filled.PlayArrow, null); Text("Ligar") }
                                OutlinedButton(onClick = {
                                    repo.diskOf(vm).delete(); onVms(vms.filter { it.id != vm.id })
                                }) { Icon(Icons.Filled.Delete, null); Text("Excluir") }
                            }
                            VmStatus.EXECUTANDO -> {
                                Button(onClick = { QemuEngine.qmp(vm.id, "stop") }) { Icon(Icons.Filled.Pause, null) }
                                OutlinedButton(onClick = { QemuEngine.qmp(vm.id, "system_reset") }) { Icon(Icons.Filled.Refresh, null) }
                                OutlinedButton(onClick = { QemuEngine.qmp(vm.id, "system_powerdown") }) { Icon(Icons.Filled.PowerSettingsNew, null) }
                                OutlinedButton(onClick = { onOpenTerminal(vm.id) }) { Icon(Icons.Filled.Terminal, null) }
                            }
                            VmStatus.PAUSADA -> {
                                Button(onClick = { QemuEngine.qmp(vm.id, "cont") }) { Icon(Icons.Filled.PlayArrow, null); Text("Continuar") }
                                OutlinedButton(onClick = { QemuEngine.kill(vm.id) }) { Text("Forçar") }
                            }
                        }
                    }
                }
            }
        }
    }
    if (creating) NewVmDialog(deviceLimits(ctx, settings), isos, onDismiss = { creating = false }) { vm ->
        onVms(vms + vm); creating = false
    }
}

@Composable
fun IntSlider(label: String, value: Int, min: Int, max: Int, step: Int, unit: String, onChange: (Int) -> Unit) {
    Column {
        Text("$label: $value $unit", fontSize = 13.sp)
        if (max > min) {
            Slider(value = value.toFloat(), valueRange = min.toFloat()..max.toFloat(),
                onValueChange = { onChange(((it / step).toInt() * step).coerceIn(min, max)) })
        } else Text("(limite do aparelho)", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun NewVmDialog(limits: Limits, isos: List<Iso>, onDismiss: () -> Unit, onCreate: (Vm) -> Unit) {
    var name by remember { mutableStateOf("alpine-1") }
    var arch by remember { mutableStateOf("aarch64") }
    var ram by remember { mutableStateOf(minOf(512, limits.maxRamMB)) }
    var cpus by remember { mutableStateOf(1) }
    var disk by remember { mutableStateOf(minOf(4, limits.maxDiskGB)) }
    var isoPath by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nova máquina") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it.take(40) }, label = { Text("Nome") }, singleLine = true)
                Text("Arquitetura (x86_64 é emulada e bem mais lenta)", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("aarch64", "x86_64").forEach { a ->
                        if (arch == a) Button(onClick = { arch = a }) { Text(a) }
                        else OutlinedButton(onClick = { arch = a }) { Text(a) }
                    }
                }
                IntSlider("Memória", ram, 256, maxOf(limits.maxRamMB, 256), 64, "MB") { ram = it }
                IntSlider("Processadores", cpus, 1, limits.maxCpus, 1, "") { cpus = it }
                IntSlider("Disco", disk, 1, limits.maxDiskGB, 1, "GB") { disk = it }
                Text("Imagem ISO", fontSize = 12.sp)
                val compatible = isos.filter { it.arch == arch || it.arch == "desconhecida" }
                if (compatible.isEmpty()) Text("Nenhuma ISO compatível. Importe na aba ISOs.", color = Color.Gray, fontSize = 12.sp)
                compatible.forEach { iso ->
                    if (isoPath == iso.path) Button(onClick = { isoPath = null }) { Text(iso.name, maxLines = 1) }
                    else OutlinedButton(onClick = { isoPath = iso.path }) { Text(iso.name, maxLines = 1) }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                onCreate(Vm(UUID.randomUUID().toString().take(8), name.trim(), "Alpine Linux", arch, ram, cpus, disk, isoPath))
            }) { Text("Criar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

private fun displayName(ctx: Context, uri: Uri): String {
    val raw = ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    } ?: "imagem.iso"
    // Só o nome do arquivo, sem caminhos, e só caracteres seguros.
    val safe = raw.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").trim('.', '_')
    return safe.ifEmpty { "imagem.iso" }
}

@Composable
fun IsosScreen(repo: Repo, isos: List<Iso>, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true; error = null
            runCatching {
                withContext(Dispatchers.IO) {
                    val base = displayName(ctx, uri)
                    var target = File(repo.isoDir, base); var n = 1
                    while (target.exists()) target = File(repo.isoDir, "${n++}_$base")
                    ctx.contentResolver.openInputStream(uri)!!.use { i -> target.outputStream().use { o -> i.copyTo(o) } }
                }
            }.onFailure { error = "Falha ao importar: ${it.message}" }
            busy = false; onChanged()
        }
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Title("Imagens ISO")
            Spacer(Modifier.height(8.dp))
            Button(enabled = !busy, onClick = { pick.launch(arrayOf("*/*")) }) { Text(if (busy) "Importando…" else "Importar ISO") }
            error?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        }
        if (isos.isEmpty()) item { Text("Nenhuma ISO importada.", color = Color.Gray) }
        items(isos, key = { it.path }) { iso ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(iso.name); Text("${fmtBytes(iso.sizeBytes)} · ${iso.arch}", color = Color.Gray, fontSize = 12.sp)
                    }
                    IconButton(onClick = { File(iso.path).delete(); onChanged() }) { Icon(Icons.Filled.Delete, "Excluir") }
                }
            }
        }
    }
}

@Composable
fun TerminalScreen(vms: List<Vm>, selected: String?, onSelect: (String?) -> Unit) {
    val running by QemuEngine.running.collectAsState()
    val console by QemuEngine.console.collectAsState()
    val id = selected?.takeIf { console.containsKey(it) || running.containsKey(it) } ?: running.keys.firstOrNull()
    var line by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Title("Terminal")
        if (id == null) { Text("Nenhuma máquina ligada.", color = Color.Gray); return@Column }
        val name = vms.firstOrNull { it.id == id }?.name ?: id
        Text("Console serial de $name. A tela gráfica (VNC) ainda não existe neste app.", color = Color.Gray, fontSize = 12.sp)
        val scroll = rememberScrollState()
        val text = console[id] ?: ""
        LaunchedEffect(text.length) { scroll.scrollTo(scroll.maxValue) }
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) {
            Text(text, Modifier.verticalScroll(scroll), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFFB8F5B8))
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(line, { line = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("comando") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { QemuEngine.send(id, line + "\n"); line = "" }))
            Button(onClick = { QemuEngine.send(id, line + "\n"); line = "" }) { Text("Enviar") }
            OutlinedButton(onClick = { QemuEngine.send(id, "\u0003") }) { Text("^C") }
        }
    }
}

@Composable
fun SettingsScreen(settings: Settings, onChange: (Settings) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("Configurações")
        IntSlider("Uso máximo de CPU", settings.maxCpuPercent, 25, 100, 5, "%") { onChange(settings.copy(maxCpuPercent = it)) }
        IntSlider("Pausar as máquinas a partir de", settings.maxTempC, 35, 50, 1, "°C") { onChange(settings.copy(maxTempC = it)) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Manter a tela ligada", Modifier.weight(1f))
            Switch(settings.keepScreenOn, { onChange(settings.copy(keepScreenOn = it)) })
        }
    }
}
