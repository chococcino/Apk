# OS LAB ANDROID — como gerar o APK

## Estado real
| Parte | Estado |
|---|---|
| Telas nativas (máquinas, ISOs, terminal serial, configurações) | Escritas (`MainActivity.kt`), **nunca compiladas** |
| Motor QEMU (`QemuEngine.kt`), serviço (`VmService.kt`), dados (`Model.kt`) | Já existiam, **nunca compilados** |
| Programas QEMU para Android | **FALTAM** — sem eles o app abre, mas não liga máquina nenhuma |
| Tela gráfica (VNC) | **Não existe** (só o console serial) |
| `scripts/fetch-qemu.py` citado no código | **Não existe** |

O primeiro build quase certamente mostrará erros de compilação: isso é esperado, mande o log.

## Caminho 1 — compilar na nuvem (sem instalar nada)
1. Crie um repositório no GitHub e envie esta pasta inteira.
2. Aba **Actions** → **Compilar APK** → **Run workflow** (também roda sozinho a cada envio).
3. Ao terminar, abra a execução e baixe **oslab-apk-debug** (um ZIP com o `.apk`).
4. Se falhar, copie o trecho vermelho do log e me envie.

## Caminho 2 — Android Studio (no computador)
Abra a pasta `android/`, aguarde a sincronização e use *Build > Build APK(s)*. O arquivo fica em
`android/app/build/outputs/apk/debug/`.

## Instalar no celular
Passe o `.apk` para o aparelho e abra. Ative "instalar apps de fontes desconhecidas" quando pedido.
É um APK de **teste** (debug), assinado com a chave de depuração. Requer Android 10 ou mais novo, ARM64.

## O que falta para ligar máquinas de verdade
O app procura estes arquivos dentro do APK, que **não estão no projeto**:
- `android/app/src/main/jniLibs/arm64-v8a/libqemu-system-aarch64.so` (e `libqemu-img.so`;
  opcional `libqemu-system-x86_64.so` para emular x86_64)
- `android/app/src/main/assets/qemu-share/` com o firmware (por exemplo `edk2-aarch64-code.fd`)

São binários do QEMU compilados para Android. Não vou inventar uma fonte para eles: é preciso
decidir de onde virão (compilar com o NDK ou aproveitar pacotes de terceiros, conferindo a licença e
se rodam fora do ambiente original). É a próxima etapa e a mais difícil. Enquanto isso o app avisa
"Motor QEMU … não está incluído" e desabilita o botão **Ligar**.
