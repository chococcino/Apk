import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { Cpu, HardDrive, LayoutDashboard, Disc3, Monitor, Settings, Terminal, Boxes } from "lucide-react";

const NAV = [
  { to: "/", label: "Painel", icon: LayoutDashboard },
  { to: "/maquinas", label: "Máquinas", icon: Boxes },
  { to: "/sistemas", label: "Sistemas", icon: Cpu },
  { to: "/terminal", label: "Terminal", icon: Terminal },
  { to: "/isos", label: "ISOs", icon: Disc3 },
  { to: "/armazenamento", label: "Disco", icon: HardDrive },
  { to: "/monitor", label: "Monitor", icon: Monitor },
  { to: "/config", label: "Config", icon: Settings },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="mx-auto flex min-h-screen max-w-3xl flex-col">
      <header className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background/90 px-4 py-3 backdrop-blur">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-primary glow" />
          <span className="font-mono text-sm font-bold tracking-[0.2em]">OS LAB <span className="text-primary">ANDROID</span></span>
        </div>
        <span className="label-tech">v0.1</span>
      </header>
      <main className="flex-1 px-4 pb-28 pt-5">{children}</main>
      <nav className="fixed inset-x-0 bottom-0 z-10 border-t border-border bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-3xl overflow-x-auto">
          {NAV.map(({ to, label, icon: Icon }) => (
            <Link key={to} to={to} activeOptions={{ exact: true }} className="flex min-w-[4.4rem] flex-1 flex-col items-center gap-1 py-2.5 text-muted-foreground data-[status=active]:text-primary">
              <Icon className="h-5 w-5" />
              <span className="font-mono text-[0.6rem] uppercase tracking-wider">{label}</span>
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}

export function PageTitle({ code, title, sub }: { code: string; title: string; sub?: string }) {
  return (
    <div className="mb-5">
      <div className="label-tech text-primary">{code}</div>
      <h1 className="mt-1 text-2xl font-bold">{title}</h1>
      {sub && <p className="mt-1 text-sm text-muted-foreground">{sub}</p>}
    </div>
  );
}

export function NativeOnly({ what }: { what: string }) {
  return (
    <div className="panel border-primary/50 p-4 text-sm">
      <div className="label-tech text-primary">Motor nativo não detectado</div>
      <p className="mt-2 text-muted-foreground">{what} só funciona no aplicativo instalado (APK), onde o QEMU roda dentro do celular. Esta prévia não simula comandos nem resultados.</p>
    </div>
  );
}

export function meta(title: string, description: string) {
  return { meta: [{ title }, { name: "description", content: description }, { property: "og:title", content: title }, { property: "og:description", content: description }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] };
}
