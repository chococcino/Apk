import { createFileRoute } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";
import { PageTitle, meta } from "@/components/lab/Shell";
import { fmtBytes, uid, update, useLab } from "@/lib/store";
import { guessIsoArch } from "@/lib/limits";

export const Route = createFileRoute("/isos")({ head: () => meta("Arquivos ISO — OS LAB", "Importe e gerencie imagens ISO."), component: Isos });

function Isos() {
  const { isos } = useLab();
  const onPick = (files: FileList | null) => {
    if (!files) return;
    const add = [...files].map((f) => ({ id: uid(), name: f.name, sizeBytes: f.size, arch: guessIsoArch(f.name), addedAt: Date.now() }));
    update((s) => ({ ...s, isos: [...s.isos, ...add] }));
  };
  return (
    <>
      <PageTitle code="04 / ISO" title="Arquivos ISO" sub="Escolha pelo seletor de arquivos do Android." />
      <label className="btn btn-primary w-full cursor-pointer">Importar ISO<input type="file" accept=".iso,.img,.qcow2" multiple className="hidden" onChange={(e) => onPick(e.target.files)} /></label>
      <div className="mt-4 space-y-3">
        {isos.length === 0 && <p className="text-sm text-muted-foreground">Nenhuma imagem importada.</p>}
        {isos.map((i) => (
          <div key={i.id} className="panel flex items-center gap-3 p-3">
            <div className="min-w-0 flex-1"><div className="truncate font-mono text-sm">{i.name}</div><div className="label-tech mt-1">{fmtBytes(i.sizeBytes)} · {i.arch}</div></div>
            <button aria-label="Excluir" className="btn px-2" onClick={() => update((s) => ({ ...s, isos: s.isos.filter((x) => x.id !== i.id) }))}><Trash2 className="h-4 w-4" /></button>
          </div>
        ))}
      </div>
      <p className="mt-4 text-xs text-muted-foreground">A arquitetura é estimada pelo nome; no APK o arquivo é inspecionado.</p>
    </>
  );
}
