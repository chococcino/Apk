import { createFileRoute } from "@tanstack/react-router";
import { NativeOnly, PageTitle, meta } from "@/components/lab/Shell";

export const Route = createFileRoute("/terminal")({ head: () => meta("Terminal — OS LAB", "Terminal conectado à máquina Linux em execução."), component: Term });

function Term() {
  return (
    <>
      <PageTitle code="03 / TERMINAL" title="Terminal" sub="Console serial ligado direto ao Linux da máquina." />
      <div className="panel min-h-64 p-3 font-mono text-xs text-muted-foreground">
        <div className="text-primary">[desconectado]</div>
        <div>Nenhuma máquina em execução.</div>
      </div>
      <div className="mt-4"><NativeOnly what="O terminal real" /></div>
    </>
  );
}
