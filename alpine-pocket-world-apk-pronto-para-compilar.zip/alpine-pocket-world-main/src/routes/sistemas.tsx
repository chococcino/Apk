import { createFileRoute } from "@tanstack/react-router";
import { PageTitle, meta } from "@/components/lab/Shell";

export const Route = createFileRoute("/sistemas")({ head: () => meta("Sistemas Linux — OS LAB", "Distribuições Linux compatíveis com o OS LAB ANDROID."), component: Systems });

const DISTROS = [
  { name: "Alpine Linux 3.20 virt", arch: "aarch64", size: "~60 MB", note: "Principal. Mesma base do OS Paranormal.", url: "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/aarch64/alpine-virt-3.20.3-aarch64.iso" },
  { name: "Alpine Linux 3.20 virt", arch: "x86_64", size: "~60 MB", note: "Emulado. Funciona, porém lento.", url: "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/x86_64/alpine-virt-3.20.3-x86_64.iso" },
];

function Systems() {
  return (
    <>
      <PageTitle code="02 / SISTEMAS" title="Sistemas Linux" sub="Baixe a imagem e importe em Arquivos ISO." />
      <div className="space-y-3">
        {DISTROS.map((d) => (
          <div key={d.url} className="panel p-4">
            <div className="flex items-center justify-between"><span className="font-bold">{d.name}</span><span className="label-tech text-primary">{d.arch}</span></div>
            <p className="mt-1 text-sm text-muted-foreground">{d.note} {d.size}</p>
            <a href={d.url} className="btn mt-3 w-full">Baixar ISO</a>
          </div>
        ))}
      </div>
      <p className="mt-4 text-xs text-muted-foreground">Nem toda ISO de computador funciona no celular. Prefira imagens “virt” e ARM64.</p>
    </>
  );
}
