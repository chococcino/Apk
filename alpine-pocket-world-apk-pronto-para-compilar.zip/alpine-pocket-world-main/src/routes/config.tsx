import { createFileRoute } from "@tanstack/react-router";
import { PageTitle, meta } from "@/components/lab/Shell";
import { update, useLab } from "@/lib/store";

export const Route = createFileRoute("/config")({ head: () => meta("Configurações — OS LAB", "Limites de uso e proteção contra superaquecimento."), component: Cfg });

function Cfg() {
  const { settings: s } = useLab();
  const set = (p: Partial<typeof s>) => update((st) => ({ ...st, settings: { ...st.settings, ...p } }));
  return (
    <>
      <PageTitle code="07 / CONFIG" title="Configurações" sub="Proteção contra travamentos e calor." />
      <div className="panel space-y-5 p-4">
        <label className="block"><div className="label-tech flex justify-between"><span>Limite de CPU</span><span className="text-foreground">{s.maxCpuPercent}%</span></div>
          <input type="range" min={25} max={100} step={5} value={s.maxCpuPercent} onChange={(e) => set({ maxCpuPercent: +e.target.value })} className="mt-2 w-full accent-primary" /></label>
        <label className="block"><div className="label-tech flex justify-between"><span>Pausar acima de</span><span className="text-foreground">{s.maxTempC}°C</span></div>
          <input type="range" min={35} max={55} value={s.maxTempC} onChange={(e) => set({ maxTempC: +e.target.value })} className="mt-2 w-full accent-primary" /></label>
        <label className="flex items-center justify-between"><span className="label-tech">Manter tela ligada</span>
          <input type="checkbox" checked={s.keepScreenOn} onChange={(e) => set({ keepScreenOn: e.target.checked })} className="h-5 w-5 accent-primary" /></label>
      </div>
    </>
  );
}
