import { createFileRoute, Link } from "@tanstack/react-router";
import { PageTitle, meta } from "@/components/lab/Shell";
import { useLab } from "@/lib/store";
import { useDevice } from "@/lib/device";

export const Route = createFileRoute("/")({ head: () => meta("OS LAB ANDROID — Painel", "Painel do laboratório de máquinas virtuais Linux no Android."), component: Dashboard });

function Stat({ k, v }: { k: string; v: string | number }) {
  return <div className="panel p-3"><div className="label-tech">{k}</div><div className="mt-1 font-mono text-2xl font-bold">{v}</div></div>;
}

function Dashboard() {
  const { vms, isos } = useLab();
  const d = useDevice();
  const running = vms.filter((v) => v.status === "executando").length;
  return (
    <>
      <PageTitle code="00 / PAINEL" title="Laboratório Linux" sub="Máquinas reais via QEMU, rodando dentro do celular." />
      <div className="grid grid-cols-2 gap-3">
        <Stat k="Máquinas" v={vms.length} />
        <Stat k="Em execução" v={running} />
        <Stat k="ISOs" v={isos.length} />
        <Stat k="Núcleos" v={d.cores} />
      </div>
      <div className="panel mt-4 p-4">
        <div className="label-tech text-primary">Início rápido</div>
        <ol className="mt-2 space-y-1 text-sm text-muted-foreground">
          <li>1. Baixe o Alpine Linux (aarch64) em Sistemas</li>
          <li>2. Importe a ISO em Arquivos ISO</li>
          <li>3. Crie uma máquina e inicie</li>
        </ol>
        <Link to="/maquinas" className="btn btn-primary mt-4 w-full">Nova máquina</Link>
      </div>
    </>
  );
}
