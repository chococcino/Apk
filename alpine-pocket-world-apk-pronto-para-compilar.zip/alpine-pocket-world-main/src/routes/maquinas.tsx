import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Play, Pause, RotateCcw, Power, Trash2 } from "lucide-react";
import { NativeOnly, PageTitle, meta } from "@/components/lab/Shell";
import { uid, update, useLab, type Vm } from "@/lib/store";
import { useDevice } from "@/lib/device";
import { clampVm, vmLimits, type Arch } from "@/lib/limits";

export const Route = createFileRoute("/maquinas")({ head: () => meta("Máquinas virtuais — OS LAB", "Crie e controle máquinas virtuais Linux."), component: Machines });

function Machines() {
  const { vms, isos } = useLab();
  const d = useDevice();
  const lim = vmLimits(d);
  const [f, setF] = useState({ name: "alpine-01", distro: "Alpine Linux", arch: "aarch64" as Arch, ramMB: 512, cpus: 1, diskGB: 2, isoId: "" });
  const [msg, setMsg] = useState("");

  const create = () => {
    const c = clampVm(f, d);
    update((s) => ({ ...s, vms: [...s.vms, { ...f, ...c, id: uid(), isoId: f.isoId || undefined, status: "parada" }] }));
    setMsg(`Máquina "${f.name}" criada.`);
  };
  const act = (v: Vm, a: string) => {
    if (a === "excluir") return update((s) => ({ ...s, vms: s.vms.filter((x) => x.id !== v.id) }));
    setMsg("Iniciar, pausar e reiniciar exigem o APK com o motor QEMU.");
  };
  const num = (k: "ramMB" | "cpus" | "diskGB", max: number, step: number, label: string) => (
    <label className="block"><div className="label-tech flex justify-between"><span>{label}</span><span className="text-foreground">{f[k]} / {max}</span></div>
      <input type="range" min={k === "ramMB" ? 128 : 1} max={max} step={step} value={f[k]} onChange={(e) => setF({ ...f, [k]: +e.target.value })} className="mt-2 w-full accent-primary" /></label>
  );

  return (
    <>
      <PageTitle code="01 / MÁQUINAS" title="Máquinas virtuais" sub="Limites calculados a partir do seu aparelho." />
      <div className="panel space-y-4 p-4">
        <input className="field" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} aria-label="Nome" />
        <div className="grid grid-cols-2 gap-3">
          <select className="field" value={f.distro} onChange={(e) => setF({ ...f, distro: e.target.value })} aria-label="Distribuição"><option>Alpine Linux</option><option>Debian</option><option>Outra</option></select>
          <select className="field" value={f.arch} onChange={(e) => setF({ ...f, arch: e.target.value as Arch })} aria-label="Arquitetura"><option value="aarch64">ARM64 (rápido)</option><option value="x86_64">x86_64 (lento)</option></select>
        </div>
        {num("ramMB", lim.maxRamMB, 64, "RAM (MB)")}
        {num("cpus", lim.maxCpus, 1, "vCPUs")}
        {num("diskGB", lim.maxDiskGB, 1, "Disco (GB)")}
        <select className="field" value={f.isoId} onChange={(e) => setF({ ...f, isoId: e.target.value })} aria-label="ISO"><option value="">Sem ISO</option>{isos.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</select>
        {f.arch === "x86_64" && <p className="text-xs text-warning">x86_64 é emulado instrução por instrução: espere um sistema bem mais lento.</p>}
        <button className="btn btn-primary w-full" onClick={create}>Criar máquina</button>
      </div>
      {msg && <p className="mt-3 font-mono text-xs text-primary">{msg}</p>}
      <div className="mt-5 space-y-3">
        {vms.map((v) => (
          <div key={v.id} className="panel p-4">
            <div className="flex items-center justify-between"><span className="font-bold">{v.name}</span><span className="label-tech">{v.status}</span></div>
            <div className="mt-1 font-mono text-xs text-muted-foreground">{v.distro} · {v.arch} · {v.ramMB}MB · {v.cpus} vCPU · {v.diskGB}GB</div>
            <div className="mt-3 grid grid-cols-5 gap-2">
              {[["iniciar", Play], ["pausar", Pause], ["reiniciar", RotateCcw], ["desligar", Power], ["excluir", Trash2]].map(([a, I]) => {
                const Icon = I as typeof Play;
                return <button key={a as string} aria-label={a as string} className="btn px-0" onClick={() => act(v, a as string)}><Icon className="h-4 w-4" /></button>;
              })}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-5"><NativeOnly what="Ligar as máquinas" /></div>
    </>
  );
}
