import { createFileRoute } from "@tanstack/react-router";
import { PageTitle, meta } from "@/components/lab/Shell";
import { useDevice } from "@/lib/device";

export const Route = createFileRoute("/monitor")({ head: () => meta("Monitor do sistema — OS LAB", "RAM, CPU, armazenamento e temperatura."), component: Mon });

function Mon() {
  const d = useDevice();
  const rows = [["RAM total (aprox.)", `${d.totalRamMB} MB`], ["Núcleos", d.cores], ["Espaço livre", `${d.freeStorageGB.toFixed(1)} GB`], ["Temperatura", "disponível no APK"], ["Uso de CPU", "disponível no APK"]];
  return (
    <>
      <PageTitle code="06 / MONITOR" title="Monitor do sistema" sub="Valores reais lidos do aparelho." />
      <div className="panel divide-y divide-border">
        {rows.map(([k, v]) => <div key={k as string} className="flex justify-between p-3"><span className="label-tech">{k}</span><span className="font-mono text-sm">{v}</span></div>)}
      </div>
    </>
  );
}
