import { createFileRoute } from "@tanstack/react-router";
import { PageTitle, meta } from "@/components/lab/Shell";
import { fmtBytes, useLab } from "@/lib/store";
import { useDevice } from "@/lib/device";

export const Route = createFileRoute("/armazenamento")({ head: () => meta("Armazenamento — OS LAB", "Espaço dos discos virtuais e ISOs."), component: Storage });

function Storage() {
  const { vms, isos } = useLab();
  const d = useDevice();
  const disks = vms.reduce((a, v) => a + v.diskGB, 0);
  const isoBytes = isos.reduce((a, i) => a + i.sizeBytes, 0);
  const total = d.freeStorageGB + d.usedStorageGB;
  const pct = total ? (d.usedStorageGB / total) * 100 : 0;
  return (
    <>
      <PageTitle code="05 / DISCO" title="Armazenamento" sub="Discos ficam no armazenamento privado do app." />
      <div className="panel p-4">
        <div className="label-tech">Espaço disponível</div>
        <div className="mt-1 font-mono text-2xl font-bold">{d.freeStorageGB.toFixed(1)} GB</div>
        <div className="mt-3 h-2 overflow-hidden rounded bg-muted"><div className="h-full bg-primary" style={{ width: `${pct}%` }} /></div>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-3">
        <div className="panel p-3"><div className="label-tech">Discos virtuais</div><div className="mt-1 font-mono text-lg">{disks} GB</div></div>
        <div className="panel p-3"><div className="label-tech">ISOs</div><div className="mt-1 font-mono text-lg">{fmtBytes(isoBytes)}</div></div>
      </div>
    </>
  );
}
