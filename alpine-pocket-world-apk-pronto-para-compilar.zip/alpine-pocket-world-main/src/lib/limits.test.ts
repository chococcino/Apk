import { describe, expect, it } from "vitest";
import { clampVm, guessIsoArch, vmLimits } from "./limits";

const phone = { totalRamMB: 8192, cores: 8, freeStorageGB: 50 };
describe("limites de VM", () => {
  it("usa no máximo metade da RAM do aparelho", () => expect(vmLimits(phone).maxRamMB).toBe(4096));
  it("deixa um núcleo livre para o Android", () => expect(vmLimits(phone).maxCpus).toBe(7));
  it("usa no máximo 80% do espaço livre", () => expect(vmLimits(phone).maxDiskGB).toBe(40));
  it("corta pedidos acima do limite", () =>
    expect(clampVm({ ramMB: 16000, cpus: 12, diskGB: 500 }, phone)).toEqual({ ramMB: 4096, cpus: 7, diskGB: 40 }));
  it("identifica arquitetura pelo nome da ISO", () => {
    expect(guessIsoArch("alpine-virt-3.20.3-aarch64.iso")).toBe("aarch64");
    expect(guessIsoArch("alpine-standard-x86_64.iso")).toBe("x86_64");
  });
});
