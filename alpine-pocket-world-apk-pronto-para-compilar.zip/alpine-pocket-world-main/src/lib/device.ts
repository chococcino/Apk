import { useEffect, useState } from "react";
import type { DeviceResources } from "./limits";

/** Lê recursos reais expostos pelo navegador (aproximados; no APK o Kotlin lê os valores exatos). */
export function useDevice() {
  const [d, setD] = useState<DeviceResources & { usedStorageGB: number; known: boolean }>({ totalRamMB: 4096, cores: 4, freeStorageGB: 8, usedStorageGB: 0, known: false });
  useEffect(() => {
    const nav = navigator as Navigator & { deviceMemory?: number };
    const ram = (nav.deviceMemory ?? 4) * 1024;
    const cores = nav.hardwareConcurrency || 4;
    const set = (free: number, used: number) => setD({ totalRamMB: ram, cores, freeStorageGB: free, usedStorageGB: used, known: true });
    if (navigator.storage?.estimate) navigator.storage.estimate().then((e) => set(((e.quota ?? 0) - (e.usage ?? 0)) / 1e9, (e.usage ?? 0) / 1e9)).catch(() => set(8, 0));
    else set(8, 0);
  }, []);
  return d;
}
