/** Limites de recursos para VMs, calculados a partir do aparelho. */
export interface DeviceResources { totalRamMB: number; cores: number; freeStorageGB: number }

export function vmLimits(d: DeviceResources) {
  // Reservamos metade da RAM e um núcleo para o Android não travar.
  const maxRamMB = Math.max(256, Math.floor(d.totalRamMB / 2 / 64) * 64);
  const maxCpus = Math.max(1, d.cores - 1);
  const maxDiskGB = Math.max(1, Math.floor(d.freeStorageGB * 0.8));
  return { maxRamMB, maxCpus, maxDiskGB };
}

export function clampVm(v: { ramMB: number; cpus: number; diskGB: number }, d: DeviceResources) {
  const l = vmLimits(d);
  return {
    ramMB: Math.min(Math.max(v.ramMB, 128), l.maxRamMB),
    cpus: Math.min(Math.max(v.cpus, 1), l.maxCpus),
    diskGB: Math.min(Math.max(v.diskGB, 1), l.maxDiskGB),
  };
}

export type Arch = "aarch64" | "x86_64" | "desconhecida";
export function guessIsoArch(name: string): Arch {
  const n = name.toLowerCase();
  if (/(aarch64|arm64)/.test(n)) return "aarch64";
  if (/(x86_64|amd64|x64)/.test(n)) return "x86_64";
  return "desconhecida";
}
