import { useSyncExternalStore } from "react";
import type { Arch } from "./limits";

export type VmStatus = "parada" | "executando" | "pausada";
export interface Vm { id: string; name: string; distro: string; arch: Arch; ramMB: number; cpus: number; diskGB: number; isoId?: string | undefined; status: VmStatus }
export interface Iso { id: string; name: string; sizeBytes: number; arch: Arch; addedAt: number }
export interface Settings { maxCpuPercent: number; maxTempC: number; keepScreenOn: boolean }
interface State { vms: Vm[]; isos: Iso[]; settings: Settings }

const KEY = "oslab-state-v1";
const initial: State = { vms: [], isos: [], settings: { maxCpuPercent: 75, maxTempC: 42, keepScreenOn: true } };
let state: State = initial;
let loaded = false;
const subs = new Set<() => void>();

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try { const raw = localStorage.getItem(KEY); if (raw) state = { ...initial, ...JSON.parse(raw) }; } catch { /* estado corrompido: começa vazio */ }
}
export function update(fn: (s: State) => State) {
  load(); state = fn(state); localStorage.setItem(KEY, JSON.stringify(state)); subs.forEach((f) => f());
}
export function useLab(): State {
  return useSyncExternalStore(
    (cb) => { load(); subs.add(cb); cb(); return () => subs.delete(cb); },
    () => state,
    () => initial,
  );
}
export const uid = () => Math.random().toString(36).slice(2, 10);
export const fmtBytes = (b: number) => {
  const u = ["B", "KB", "MB", "GB", "TB"]; let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return `${b.toFixed(i ? 1 : 0)} ${u[i]}`;
};
